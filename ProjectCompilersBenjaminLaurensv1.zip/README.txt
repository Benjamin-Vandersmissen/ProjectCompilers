Not working:
- constant declaration of array (normal with variables do work)

optional requirements:
- constant folding
- skipping code after return statement
- skip unused expressions
- in global scope, only take last constant declaration for a variable
- error if no return statement is given in non-void function

tests:
All tests can be found in the tests folder. The name of the test says what it will test and in the testfile more explanation is given.