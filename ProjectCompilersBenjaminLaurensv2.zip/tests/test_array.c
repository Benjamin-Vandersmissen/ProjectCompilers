// Test all different kinds of arrays and accessing an element of it

int a[] = {1,2,3,4};

char test[] = {'y', 'o', 'u', ' ', 't', 'y', 'p', 'e', 'd', ':', 10, '%', 'f', 10, 0};

char test2[] = "ddddd  dfgrh 1234 @$^^@$";

int main(){

    int b[5] = {1, 2, 3};
    int c = 0;
    int d[] = {c, 1, 2};
    int e = b[4];
    return 0;
}